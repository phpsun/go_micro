server_name=$1
cd /Users/seven/www/go_micro_init/goserver/src/${server_name}_server 
go build -o /Users/seven/www/go_micro_init_build/${server_name}-server main.go

/Users/seven/www/go_micro_init_build/${server_name}-server -config=/Users/seven/www/go_micro_init_build/config/${server_name}-test.toml
